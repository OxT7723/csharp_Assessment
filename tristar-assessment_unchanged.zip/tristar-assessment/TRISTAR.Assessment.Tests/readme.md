# TRISTAR.Assessment.Tests

This project contains the integration tests for the assessment as well as support classes to facilitate the tests. The integration tests are located in [PersonIntegrationTests](PersonIntegrationTests.cs). You are __not__ allowed to modify them to make them pass.

When you complete the assessment, all tests should pass. You can verify the state of the tests by using Visual Studio's Test Explorer.
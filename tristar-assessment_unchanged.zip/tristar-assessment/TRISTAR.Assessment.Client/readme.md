# TRISTAR.Assessment.Client

This project contains all classes that could be used by a client to communicate with server (http api).

In this project, your goal is to make the `PersonClientRepository` work by implementing its methods to communicate with the server that is contained in this solution.
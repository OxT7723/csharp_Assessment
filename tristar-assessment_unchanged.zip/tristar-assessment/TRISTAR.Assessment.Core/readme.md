# TRISTAR.Assessment.Core

This project contains all code that is common to both the client and server. For example, the `IPersonRepository` interface is implemented by both the `PersonClientRepository` and `PersonServerRepository` classes, so it is contained in this project where it can be shared.